my_gen = (x for x in range(10, 21) if x % 2 == 0)
for num in my_gen:
    print(num)