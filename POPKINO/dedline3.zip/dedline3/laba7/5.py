a = input("введите данное: ")
b, c = map(str, input("строка один, два: ",).split())
print('получившийся текст: ' , a.replace(b, c,))